Title: A markdown powered article
Date: 2011-04-20

You're mutually oblivious.

[a root-relative link to unbelievable](|filename|/unbelievable.rst)
[a file-relative link to unbelievable](|filename|../unbelievable.rst)
