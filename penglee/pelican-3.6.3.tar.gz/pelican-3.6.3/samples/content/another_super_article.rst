Oh yeah !
#########

:tags: oh, bar, yeah
:date: 2010-10-20 10:14
:category: bar
:author: Alexis Métaireau
:slug: oh-yeah
:license: WTFPL

Why not ?
=========

After all, why not ? It's pretty simple to do it, and it will allow me to write my blogposts in rst !
YEAH !

.. image:: |filename|/pictures/Sushi.jpg
   :height: 450 px
   :width: 600 px
   :alt: alternate text
