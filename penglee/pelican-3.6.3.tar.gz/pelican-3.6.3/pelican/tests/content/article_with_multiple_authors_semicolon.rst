This is an article with multiple authors in lastname, firstname format!
#######################################################################

:date: 2014-02-09 02:20
:modified: 2014-02-09 02:20
:authors: Author, First; Author, Second
