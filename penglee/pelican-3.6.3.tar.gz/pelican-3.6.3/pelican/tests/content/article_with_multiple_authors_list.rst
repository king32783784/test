This is an article with multiple authors in list format!
########################################################

:date: 2014-02-09 02:20
:modified: 2014-02-09 02:20
:authors: - Author, First
          - Author, Second

The author names are in last,first form to verify that
they are not just getting split on commas.
