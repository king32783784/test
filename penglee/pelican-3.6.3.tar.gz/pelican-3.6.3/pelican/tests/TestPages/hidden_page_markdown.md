title: This is a markdown test hidden page
status: hidden

Test Markdown File Header
=========================

Used for pelican test
---------------------

The quick brown fox jumped over the lazy dog's back.

This page is hidden
